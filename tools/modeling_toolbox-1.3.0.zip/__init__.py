import re

import bpy
from mathutils import Vector


SUFFIX_PATTERN = re.compile(r"^(.*)\.(\d{3})$")
CHECKERBOARD_MATERIAL_NAME = "建模工具箱_棋盘格材质"


def fix_materials(objects):
    relinked = 0
    renamed = 0
    removed = 0
    skipped = 0

    for obj in objects:
        data = getattr(obj, "data", None)
        if data is None or not hasattr(data, "materials"):
            continue

        mats = data.materials
        for index, mat in enumerate(mats):
            if mat is None:
                continue

            match = SUFFIX_PATTERN.match(mat.name)
            if not match:
                continue

            base_name = match.group(1)
            base_mat = bpy.data.materials.get(base_name)

            if base_mat is not None and base_mat != mat:
                mats[index] = base_mat
                relinked += 1

    for mat in list(bpy.data.materials):
        match = SUFFIX_PATTERN.match(mat.name)
        if not match:
            continue

        base_name = match.group(1)
        base_mat = bpy.data.materials.get(base_name)

        if base_mat is not None and base_mat != mat:
            if mat.users == 0:
                bpy.data.materials.remove(mat)
                removed += 1
            else:
                skipped += 1
            continue

        if base_mat is None:
            try:
                mat.name = base_name
                renamed += 1
            except RuntimeError:
                skipped += 1

    return relinked, renamed, removed, skipped


def get_or_create_checkerboard_material():
    material = bpy.data.materials.get(CHECKERBOARD_MATERIAL_NAME)
    if material is None:
        material = bpy.data.materials.new(CHECKERBOARD_MATERIAL_NAME)

    material.use_nodes = True
    node_tree = material.node_tree
    nodes = node_tree.nodes
    links = node_tree.links
    nodes.clear()

    output_node = nodes.new("ShaderNodeOutputMaterial")
    output_node.location = (420, 0)

    shader_node = nodes.new("ShaderNodeBsdfPrincipled")
    shader_node.location = (120, 0)

    checker_node = nodes.new("ShaderNodeTexChecker")
    checker_node.location = (-120, 0)
    checker_node.inputs["Color1"].default_value = (0.04, 0.04, 0.04, 1.0)
    checker_node.inputs["Color2"].default_value = (0.8, 0.8, 0.8, 1.0)
    checker_node.inputs["Scale"].default_value = 12.0

    texture_coordinate_node = nodes.new("ShaderNodeTexCoord")
    texture_coordinate_node.location = (-360, 0)

    links.new(
        texture_coordinate_node.outputs["UV"],
        checker_node.inputs["Vector"],
    )
    links.new(checker_node.outputs["Color"], shader_node.inputs["Base Color"])
    links.new(shader_node.outputs["BSDF"], output_node.inputs["Surface"])

    return material


def replace_all_materials_with_checkerboard(objects):
    checkerboard_material = get_or_create_checkerboard_material()
    changed_slots = 0
    changed_objects = 0

    for obj in objects:
        data = getattr(obj, "data", None)
        if data is None or not hasattr(data, "materials"):
            continue

        object_changed = False
        for index in range(len(data.materials)):
            if data.materials[index] != checkerboard_material:
                data.materials[index] = checkerboard_material
                changed_slots += 1
                object_changed = True

        if object_changed:
            changed_objects += 1

    return changed_objects, changed_slots


def remove_unused_mesh_material_slots(objects):
    cleaned_objects = 0
    removed_slots = 0
    skipped_objects = 0
    view_layer = bpy.context.view_layer

    for obj in objects:
        if obj.type != 'MESH':
            continue

        data = getattr(obj, "data", None)
        if data is None or not hasattr(data, "materials"):
            continue

        slot_count_before = len(obj.material_slots)
        if slot_count_before == 0:
            continue

        used_indices = {poly.material_index for poly in data.polygons}
        unused_indices = [
            index for index in range(slot_count_before)
            if index not in used_indices
        ]

        if not unused_indices:
            continue

        try:
            with bpy.context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
            ):
                bpy.ops.object.material_slot_remove_unused()
        except RuntimeError:
            skipped_objects += 1
            continue

        slot_count_after = len(obj.material_slots)
        removed_now = slot_count_before - slot_count_after
        if removed_now > 0:
            cleaned_objects += 1
            removed_slots += removed_now

    return cleaned_objects, removed_slots, skipped_objects


def make_mesh_single_user(obj):
    if obj.data is not None and obj.data.users > 1:
        obj.data = obj.data.copy()


def compute_lowest_world_z(obj):
    if obj.type != 'MESH' or obj.data is None or len(obj.data.vertices) == 0:
        return None

    world_matrix = obj.matrix_world
    world_vertices = [world_matrix @ vertex.co for vertex in obj.data.vertices]
    return min(vertex.z for vertex in world_vertices)


def apply_all_transforms(objects):
    candidates = [
        obj for obj in objects
        if obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'GPENCIL', 'GREASEPENCIL', 'ARMATURE', 'LATTICE', 'EMPTY'}
    ]
    if not candidates:
        return 0, 0

    with bpy.context.temp_override(
        active_object=candidates[0],
        object=candidates[0],
        selected_objects=candidates,
        selected_editable_objects=candidates,
    ):
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    return len(candidates), max(0, len(objects) - len(candidates))


def set_origin_to_lowest_center(objects):
    moved = 0
    skipped = 0
    scene = bpy.context.scene
    view_layer = bpy.context.view_layer
    cursor_location = scene.cursor.location.copy()
    active_object = view_layer.objects.active

    try:
        for obj in objects:
            lowest_z = compute_lowest_world_z(obj)
            if lowest_z is None:
                skipped += 1
                continue

            make_mesh_single_user(obj)
            with bpy.context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
                scene=scene,
            ):
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')

            current_origin = obj.matrix_world.translation.copy()
            scene.cursor.location = Vector((current_origin.x, current_origin.y, lowest_z))
            with bpy.context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
                scene=scene,
            ):
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')

            moved += 1
    finally:
        scene.cursor.location = cursor_location
        view_layer.objects.active = active_object

    return moved, skipped


def set_origin_to_lowest_volume_center(objects):
    moved = 0
    skipped = 0
    scene = bpy.context.scene
    view_layer = bpy.context.view_layer
    cursor_location = scene.cursor.location.copy()
    active_object = view_layer.objects.active

    try:
        for obj in objects:
            lowest_z = compute_lowest_world_z(obj)
            if lowest_z is None:
                skipped += 1
                continue

            make_mesh_single_user(obj)
            with bpy.context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
                scene=scene,
            ):
                bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME', center='MEDIAN')

            current_origin = obj.matrix_world.translation.copy()
            scene.cursor.location = Vector((current_origin.x, current_origin.y, lowest_z))
            with bpy.context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
                scene=scene,
            ):
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')

            moved += 1
    finally:
        scene.cursor.location = cursor_location
        view_layer.objects.active = active_object

    return moved, skipped


def set_origin_to_world_origin(objects):
    moved = 0
    skipped = 0
    scene = bpy.context.scene
    view_layer = bpy.context.view_layer
    cursor_location = scene.cursor.location.copy()
    active_object = view_layer.objects.active

    try:
        scene.cursor.location = Vector((0.0, 0.0, 0.0))
        for obj in objects:
            if obj.type != 'MESH' or obj.data is None:
                skipped += 1
                continue

            make_mesh_single_user(obj)
            with bpy.context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
                scene=scene,
            ):
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            moved += 1
    finally:
        scene.cursor.location = cursor_location
        view_layer.objects.active = active_object

    return moved, skipped


def move_objects_to_world_origin(objects):
    moved = 0
    skipped = 0

    for obj in objects:
        if obj.type == 'MESH' and obj.data is not None:
            obj.location = (0.0, 0.0, 0.0)
            moved += 1
        else:
            skipped += 1

    return moved, skipped


class OBJECT_OT_fix_fbx_material_names(bpy.types.Operator):
    bl_idname = "object.fix_fbx_material_names"
    bl_label = "Fix FBX Material Names"
    bl_description = "Merge duplicate material names or remove numeric suffixes"
    bl_options = {'REGISTER', 'UNDO'}

    selected_only: bpy.props.BoolProperty(
        name="Selected Objects Only",
        description="Only process materials used by selected objects",
        default=True,
    )

    def execute(self, context):
        objects = context.selected_objects if self.selected_only else bpy.data.objects
        relinked, renamed, removed, skipped = fix_materials(objects)

        message = (
            f"材质槽合并 {relinked} 个，材质重命名 {renamed} 个，"
            f"删除重复材质 {removed} 个，跳过 {skipped} 个"
        )
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class OBJECT_OT_replace_all_materials_with_checkerboard(bpy.types.Operator):
    bl_idname = "object.replace_all_materials_with_checkerboard"
    bl_label = "Replace All Materials With Checkerboard"
    bl_description = "Replace every material slot in the current file with a checkerboard material"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        changed_objects, changed_slots = replace_all_materials_with_checkerboard(bpy.data.objects)
        message = f"棋盘格材质已应用到 {changed_objects} 个对象、{changed_slots} 个材质槽"
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class OBJECT_OT_remove_unused_mesh_material_slots(bpy.types.Operator):
    bl_idname = "object.remove_unused_mesh_material_slots_batch"
    bl_label = "Remove Unused Mesh Material Slots"
    bl_description = "Batch remove mesh material slots that are not used by any faces"
    bl_options = {'REGISTER', 'UNDO'}

    selected_only: bpy.props.BoolProperty(
        name="Selected Objects Only",
        description="Only process selected mesh objects",
        default=True,
    )

    def execute(self, context):
        objects = context.selected_objects if self.selected_only else bpy.data.objects
        cleaned_objects, removed_slots, skipped_objects = remove_unused_mesh_material_slots(objects)

        message = (
            f"清理对象 {cleaned_objects} 个，删除未使用材质槽 {removed_slots} 个，"
            f"跳过对象 {skipped_objects} 个"
        )
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class OBJECT_OT_apply_all_transforms_selected(bpy.types.Operator):
    bl_idname = "object.apply_all_transforms_selected_batch"
    bl_label = "Apply All Transforms"
    bl_description = "Apply location, rotation, and scale to selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        processed, skipped = apply_all_transforms(list(context.selected_objects))
        message = f"应用变换对象 {processed} 个，跳过 {skipped} 个"
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class OBJECT_OT_set_origin_to_lowest_center(bpy.types.Operator):
    bl_idname = "object.set_origin_to_lowest_center_batch"
    bl_label = "Origin To Lowest Center"
    bl_description = "Move the origin to the center of the model's lowest points"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        moved, skipped = set_origin_to_lowest_center(list(context.selected_objects))
        message = f"移动原点对象 {moved} 个，跳过 {skipped} 个"
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class OBJECT_OT_set_origin_to_lowest_volume_center(bpy.types.Operator):
    bl_idname = "object.set_origin_to_lowest_volume_center_batch"
    bl_label = "Origin To Lowest Volume Center"
    bl_description = "Move the origin to the volume center, then place it at the model's lowest world Z"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        moved, skipped = set_origin_to_lowest_volume_center(list(context.selected_objects))
        message = f"移动体积中心原点对象 {moved} 个，跳过 {skipped} 个"
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class OBJECT_OT_set_origin_to_world_origin(bpy.types.Operator):
    bl_idname = "object.set_origin_to_world_origin_batch"
    bl_label = "Origin To World Origin"
    bl_description = "Move the origin to the world origin while keeping mesh geometry in place"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        moved, skipped = set_origin_to_world_origin(list(context.selected_objects))
        message = f"移动到世界原点对象 {moved} 个，跳过 {skipped} 个"
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class OBJECT_OT_move_objects_to_world_origin(bpy.types.Operator):
    bl_idname = "object.move_objects_to_world_origin_batch"
    bl_label = "Move Objects To World Origin"
    bl_description = "Move selected mesh objects to the world origin"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        moved, skipped = move_objects_to_world_origin(list(context.selected_objects))
        message = f"移动物体到世界中心 {moved} 个，跳过 {skipped} 个"
        self.report({'INFO'}, message)
        print(message)
        return {'FINISHED'}


class VIEW3D_PT_modeling_toolbox(bpy.types.Panel):
    bl_label = "建模工具箱"
    bl_idname = "VIEW3D_PT_modeling_toolbox"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'

    def draw(self, _context):
        layout = self.layout
        transform_box = layout.box()
        transform_box.label(text="变换工具", icon='OBJECT_ORIGIN')
        transform_box.operator(
            "object.apply_all_transforms_selected_batch",
            text="对选中物体应用所有变换",
            icon='FILE_REFRESH',
        )

        origin_box = layout.box()
        origin_box.label(text="原点工具", icon='PIVOT_BOUNDBOX')
        origin_box.operator(
            "object.set_origin_to_lowest_center_batch",
            text="原点移到模型最低点中心",
            icon='TRIA_DOWN_BAR',
        )
        origin_box.operator(
            "object.set_origin_to_lowest_volume_center_batch",
            text="原点移到体积中心最低点",
            icon='SNAP_FACE_CENTER',
        )
        origin_box.operator(
            "object.set_origin_to_world_origin_batch",
            text="原点移到世界原点",
            icon='WORLD_DATA',
        )
        origin_box.operator(
            "object.move_objects_to_world_origin_batch",
            text="移动物体到世界中心",
            icon='EMPTY_ARROWS',
        )

        material_box = layout.box()
        material_box.label(text="材质工具", icon='MATERIAL')
        op = material_box.operator(
            "object.fix_fbx_material_names",
            text="修复材质序号（选中物体）",
            icon='MATERIAL',
        )
        op.selected_only = True
        op = material_box.operator(
            "object.fix_fbx_material_names",
            text="修复材质序号（全部物体）",
            icon='NODE_MATERIAL',
        )
        op.selected_only = False
        material_box.operator(
            "object.replace_all_materials_with_checkerboard",
            text="所有材质替换为棋盘格",
            icon='TEXTURE',
        )
        op = material_box.operator(
            "object.remove_unused_mesh_material_slots_batch",
            text="删除未使用材质槽（选中物体）",
            icon='TRASH',
        )
        op.selected_only = True
        op = material_box.operator(
            "object.remove_unused_mesh_material_slots_batch",
            text="删除未使用材质槽（全部物体）",
            icon='TRASH',
        )
        op.selected_only = False


classes = (
    OBJECT_OT_fix_fbx_material_names,
    OBJECT_OT_replace_all_materials_with_checkerboard,
    OBJECT_OT_remove_unused_mesh_material_slots,
    OBJECT_OT_apply_all_transforms_selected,
    OBJECT_OT_set_origin_to_lowest_center,
    OBJECT_OT_set_origin_to_lowest_volume_center,
    OBJECT_OT_set_origin_to_world_origin,
    OBJECT_OT_move_objects_to_world_origin,
    VIEW3D_PT_modeling_toolbox,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
